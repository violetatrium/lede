#!/bin/bash

modprobe -rq jool
modprobe -rq jool_siit
