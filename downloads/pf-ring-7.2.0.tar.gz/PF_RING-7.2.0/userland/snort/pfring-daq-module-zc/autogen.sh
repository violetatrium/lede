#!/bin/bash

autoreconf -ivf
