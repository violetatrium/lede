// SPDX-License-Identifier: GPL-2.0
/* Copyright (C) 2010-2019  B.A.T.M.A.N. contributors:
 *
 * Sven Eckelmann
 */

#define CREATE_TRACE_POINTS
#include "trace.h"
