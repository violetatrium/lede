Installation
------------

nBroker is part of the PF_RING distribution, you can compile and install it running the commands below:

.. code-block:: console

   cd <PF_RING PATH>/userland/nbroker
   ./configure
   make install

