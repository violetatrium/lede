# Doc

This folder is just a small fraction of the developer documentation. More can
be found in the [Github wiki](https://github.com/NICMx/Jool/wiki) and more yet
scattered through the code and other READMEs.

The user documentation, on the other hand, can be found at

- https://jool.mx/en/index.html (compiled)
- https://nicmx.github.io/Jool/en/index.html (compiled)
- This git project's gh-pages branch. (source)
- https://github.com/NICMx/Jool/tree/gh-pages (source)
