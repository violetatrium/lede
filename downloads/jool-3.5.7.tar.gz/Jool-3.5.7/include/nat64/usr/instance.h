#ifndef _JOOL_USR_INSTANCE_H
#define _JOOL_USR_INSTANCE_H

int instance_add(void);
int instance_rm(void);

#endif /* _JOOL_USR_INSTANCE_H */
