#!/bin/bash

. config

cd $JOOL_DIR/test/graybox
./run-netns-graybox.sh

