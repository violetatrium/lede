#ifndef __NL_INSTANCE_H__
#define __NL_INSTANCE_H__

#include <net/genetlink.h>

int handle_instance_request(struct genl_info *info);

#endif
